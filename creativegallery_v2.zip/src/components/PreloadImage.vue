<template>
    <div id="container" class="bg-brandgray absolute w-screen h-screen z-30 flex flex-col items-center justify-center space-y-6">
        <div id="preloadimg" class="w-6/12 md:w-4/12 lg:w-2/12 animate-updown"><img src="../assets/images/yoda.png"/></div>
        <div class="flex flex-row justify-center"><img class="w-[300px] md:w-[500px] 2xl:w-[700px]" src="../assets/images/creative-forces.svg"/></div>
        <div class="flex flex-row justify-center"><img class="w-[100px] md:w-[150px]"  src="../assets/images/logo.png"/></div>
   </div>      
</template>
